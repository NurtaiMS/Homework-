module com.example.demo3 {
    requires javafx.controls;
    requires javafx.fxml;
    requires jdk.incubator.vector;
    requires org.apache.poi.ooxml;
    requires org.apache.poi.poi;

    opens com.example.demo3 to javafx.fxml;
    exports com.example.demo3;
}