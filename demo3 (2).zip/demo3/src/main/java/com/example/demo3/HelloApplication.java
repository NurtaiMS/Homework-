package com.example.demo3;

import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.Scene;
import javafx.scene.chart.*;
import javafx.scene.control.Button;
import javafx.scene.layout.VBox;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.File;
import java.io.FileInputStream;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class HelloApplication extends Application {
    private final ArrayList<Product> products = new ArrayList<>();
    private final Map<Integer, Map<Integer, Double>> profitData = new HashMap<>();

    private LineChart<String, Number> chart;  // График, который будет обновляться

    @Override
    public void start(Stage stage) {
        VBox root = new VBox(15);  // spacing between elements
        root.setStyle("-fx-padding: 20;");

        // Button to load Excel file
        Button loadButton = new Button("Загрузить Excel-файл");
        loadButton.setOnAction(event -> onLoadExcelClick());

        // Chart setup
        final CategoryAxis xAxis = new CategoryAxis();
        final NumberAxis yAxis = new NumberAxis();
        xAxis.setLabel("Месяц");
        yAxis.setLabel("Прибыль");

        chart = new LineChart<>(xAxis, yAxis);
        chart.setTitle("Продажи");

        // Add button and chart to the VBox
        root.getChildren().addAll(loadButton, chart);

        // Create the scene and show it
        Scene scene = new Scene(root, 800, 600);
        stage.setTitle("Анализ продаж");
        stage.setScene(scene);
        stage.show();
    }

    private void onLoadExcelClick() {
        // Open file chooser to select Excel file
        FileChooser fileChooser = new FileChooser();
        fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("Excel Files", "*.xlsx"));
        File file = fileChooser.showOpenDialog(new Stage());

        if (file != null) {
            loadExcelFile(file);  // Load the Excel file
            showChartForSelectedYear();  // Show the chart
        }
    }

    private void loadExcelFile(File file) {
        profitData.clear();

        try (FileInputStream fis = new FileInputStream(file);
             Workbook workbook = new XSSFWorkbook(fis)) {

            Sheet sheet = workbook.getSheetAt(0);

            for (Row row : sheet) {
                if (row.getRowNum() == 0) continue;  // Skip header row

                Cell dateCell = row.getCell(5);  // Date in the 6th cell (index 5)

                if (dateCell == null) continue;

                LocalDate date = null;

                // Handle date cell
                if (dateCell.getCellType() == CellType.NUMERIC && DateUtil.isCellDateFormatted(dateCell)) {
                    date = dateCell.getLocalDateTimeCellValue().toLocalDate();
                } else if (dateCell.getCellType() == CellType.STRING) {
                    try {
                        date = LocalDate.parse(dateCell.getStringCellValue(), java.time.format.DateTimeFormatter.ofPattern("dd.MM.yyyy"));
                    } catch (Exception ignored) {}
                }

                if (date == null) continue;

                int year = date.getYear();
                int month = date.getMonthValue();

                // Profit in the 5th cell (index 4)
                Cell totalCell = row.getCell(4);
                if (totalCell == null || totalCell.getCellType() != CellType.NUMERIC) continue;

                double profit = totalCell.getNumericCellValue();

                // Add profit to data
                profitData.putIfAbsent(year, new HashMap<>());
                Map<Integer, Double> monthlyData = profitData.get(year);
                monthlyData.put(month, monthlyData.getOrDefault(month, 0.0) + profit);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void showChartForSelectedYear() {
        // Display data for selected year
        if (profitData.isEmpty()) return;

        // Select the latest year
        int selectedYear = profitData.keySet().stream().max(Integer::compare).orElseThrow();
        Map<Integer, Double> monthlyData = profitData.get(selectedYear);

        // Create a new series of data
        XYChart.Series<String, Number> series = new XYChart.Series<>();
        String[] monthNames = {"Янв", "Фев", "Мар", "Апр", "Май", "Июн", "Июл", "Авг", "Сен", "Окт", "Ноя", "Дек"};

        // Add data to the series
        for (int i = 1; i <= 12; i++) {
            double value = monthlyData.getOrDefault(i, 0.0);
            series.getData().add(new XYChart.Data<>(monthNames[i - 1], value));
        }

        // Clear existing data and add new data to chart
        chart.getData().clear();
        chart.getData().add(series);
    }

    public static void main(String[] args) {
        launch();
    }
}
