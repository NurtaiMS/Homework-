package com.example.demo3;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.chart.CategoryAxis;
import javafx.scene.chart.LineChart;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;
import javafx.scene.control.ComboBox;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.File;
import java.io.FileInputStream;
import java.time.LocalDate;
import java.util.HashMap;
import java.util.Map;

public class HelloController {

    @FXML
    private ComboBox<Integer> yearComboBox;

    @FXML
    private LineChart<String, Number> lineChart;

    // Хранилище прибыли по годам и месяцам
    private final Map<Integer, Map<Integer, Double>> profitData = new HashMap<>();

    @FXML
    protected void onLoadExcelClick() {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Выберите Excel-файл");
        fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("Excel Files", "*.xlsx"));

        File file = fileChooser.showOpenDialog(new Stage());
        if (file != null) {
            loadExcelFile(file);
            fillYearComboBox();
        }
    }

    private void loadExcelFile(File file) {
        profitData.clear();

        try (FileInputStream fis = new FileInputStream(file);
             Workbook workbook = new XSSFWorkbook(fis)) {

            Sheet sheet = workbook.getSheetAt(0);

            for (Row row : sheet) {
                if (row.getRowNum() == 0) continue; // пропустить заголовок

                Cell dateCell = row.getCell(5); // дата в 6-й ячейке (index 5)

                if (dateCell == null) continue;

                LocalDate date = null;

                if (dateCell.getCellType() == CellType.NUMERIC && DateUtil.isCellDateFormatted(dateCell)) {
                    date = dateCell.getLocalDateTimeCellValue().toLocalDate();
                } else if (dateCell.getCellType() == CellType.STRING) {
                    try {
                        date = LocalDate.parse(dateCell.getStringCellValue(), java.time.format.DateTimeFormatter.ofPattern("dd.MM.yyyy"));
                    } catch (Exception ignored) {}
                }

                if (date == null) continue;

                int year = date.getYear();
                int month = date.getMonthValue();

                // Прибыль в 5-й ячейке (index 4)
                Cell totalCell = row.getCell(4);
                if (totalCell == null || totalCell.getCellType() != CellType.NUMERIC) continue;

                double profit = totalCell.getNumericCellValue();

                // Добавляем прибыль в данные
                profitData.putIfAbsent(year, new HashMap<>());
                Map<Integer, Double> monthlyData = profitData.get(year);
                monthlyData.put(month, monthlyData.getOrDefault(month, 0.0) + profit);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void fillYearComboBox() {
        ObservableList<Integer> years = FXCollections.observableArrayList(profitData.keySet());
        FXCollections.sort(years);
        yearComboBox.setItems(years);

        if (!years.isEmpty()) {
            yearComboBox.getSelectionModel().selectLast(); // Выбираем последний год
            showChartForSelectedYear(); // Сразу отображаем график для последнего года
        }
    }

    @FXML
    protected void onYearSelected() {
        showChartForSelectedYear();
    }

    private void showChartForSelectedYear() {
        Integer selectedYear = yearComboBox.getValue();
        if (selectedYear == null || !profitData.containsKey(selectedYear)) return;

        Map<Integer, Double> monthlyData = profitData.get(selectedYear);
        lineChart.getData().clear();

        XYChart.Series<String, Number> series = new XYChart.Series<>();
        series.setName("Прибыль за " + selectedYear);

        String[] monthNames = {"Янв", "Фев", "Мар", "Апр", "Май", "Июн",
                "Июл", "Авг", "Сен", "Окт", "Ноя", "Дек"};

        for (int i = 1; i <= 12; i++) {
            double value = monthlyData.getOrDefault(i, 0.0);
            series.getData().add(new XYChart.Data<>(monthNames[i - 1], value));
        }

        lineChart.getData().add(series);
    }
}
